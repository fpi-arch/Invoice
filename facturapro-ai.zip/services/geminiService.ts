import { GoogleGenAI } from "@google/genai";
import { Invoice } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeSales = async (invoices: Invoice[]) => {
  if (invoices.length === 0) return "No hay datos de ventas para analizar.";

  const salesSummary = invoices.map(inv => ({
    date: inv.date,
    total: inv.total,
    client: inv.clientName,
    items: inv.items.map(i => i.productName).join(', ')
  }));

  const prompt = `
    Analiza los siguientes datos de facturación (formato JSON simplificado).
    Genera un reporte ejecutivo breve (máximo 3 párrafos) en español.
    Identifica:
    1. Tendencias de ingresos.
    2. Mejores clientes.
    3. Productos más vendidos.
    4. Una recomendación estratégica para mejorar las ventas.

    Datos:
    ${JSON.stringify(salesSummary)}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error analyzing sales:", error);
    return "No se pudo generar el análisis en este momento. Verifique su conexión o clave API.";
  }
};

export const generateLogo = async (companyName: string, description: string): Promise<string | null> => {
  const prompt = `Diseña un logotipo vectorial moderno, minimalista y profesional para una empresa llamada '${companyName}'. 
  Concepto: ${description}. 
  Estilo: Flat design, alta calidad, fondo blanco, colores corporativos serios (azul, gris, negro).
  Importante: El logotipo debe ser claro y simple.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }]
      }
    });

    // Extract image
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating logo:", error);
    throw error;
  }
};