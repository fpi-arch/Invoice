import { Client, Product, Invoice, CompanyProfile, TaxSetting, User } from '../types';

const KEYS = {
  CLIENTS: 'facturapro_clients',
  PRODUCTS: 'facturapro_products',
  INVOICES: 'facturapro_invoices',
  COMPANY: 'facturapro_company',
  TAXES: 'facturapro_taxes',
  USERS: 'facturapro_users',
};

// Initial Dummy Data
const initialClients: Client[] = [
  { id: '1', name: 'Empresa Alpha S.A.', taxId: 'XAXX010101000', email: 'contacto@alpha.com', address: 'Av. Principal 123', city: 'Ciudad de México', zip: '06000', phone: '555-0101', country: 'México' },
  { id: '2', name: 'Consultoría Beta', taxId: 'XBXX020202000', email: 'finanzas@beta.com', address: 'Calle Secundaria 456', city: 'Monterrey', zip: '64000', phone: '818-0202', country: 'México' },
];

const initialProducts: Product[] = [
  { id: '1', code: 'SERV-001', name: 'Consultoría TI', price: 1500.00, unit: 'servicio', description: 'Hora de consultoría especializada' },
  { id: '2', code: 'SOFT-001', name: 'Licencia Anual', price: 3000.00, unit: 'pieza', description: 'Licencia de uso de software por 1 año' },
  { id: '3', code: 'SUP-002', name: 'Soporte Mensual', price: 800.00, unit: 'servicio', description: 'Mantenimiento y soporte técnico básico' },
];

const initialCompany: CompanyProfile = {
  name: 'Mi Empresa S.A. de C.V.',
  taxId: 'EMP000000XXX',
  address: 'Calle Negocio 123, Ciudad de México',
  currency: 'MXN',
  apiConfig: {
    provider: 'GENERIC',
    environment: 'sandbox',
    apiKey: '',
    apiSecret: ''
  }
};

const initialTaxes: TaxSetting[] = [
  { id: '1', name: 'IVA General (16%)', rate: 0.16, type: 'tax' },
  { id: '2', name: 'IVA Frontera (8%)', rate: 0.08, type: 'tax' },
  { id: '3', name: 'Exento (0%)', rate: 0, type: 'tax' },
  { id: '4', name: 'Retención ISR (10%)', rate: 0.10, type: 'retention' },
  { id: '5', name: 'Retención IVA (10.66%)', rate: 0.1066, type: 'retention' },
  { id: '6', name: 'Sin Retención', rate: 0, type: 'retention' },
];

const initialUsers: User[] = [
  { id: '1', name: 'Admin Principal', email: 'admin@empresa.com', role: 'admin', status: 'active', lastAccess: '2023-10-27' },
  { id: '2', name: 'Contador General', email: 'contabilidad@empresa.com', role: 'manager', status: 'active', lastAccess: '2023-10-26' },
  { id: '3', name: 'Auditor Externo', email: 'auditor@firma.com', role: 'viewer', status: 'inactive', lastAccess: '2023-09-15' },
];

export const storage = {
  getClients: (): Client[] => {
    const data = localStorage.getItem(KEYS.CLIENTS);
    return data ? JSON.parse(data) : initialClients;
  },
  saveClients: (clients: Client[]) => localStorage.setItem(KEYS.CLIENTS, JSON.stringify(clients)),

  getProducts: (): Product[] => {
    const data = localStorage.getItem(KEYS.PRODUCTS);
    return data ? JSON.parse(data) : initialProducts;
  },
  saveProducts: (products: Product[]) => localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products)),

  getInvoices: (): Invoice[] => {
    const data = localStorage.getItem(KEYS.INVOICES);
    return data ? JSON.parse(data) : [];
  },
  saveInvoices: (invoices: Invoice[]) => localStorage.setItem(KEYS.INVOICES, JSON.stringify(invoices)),

  getNextInvoiceNumber: (): string => {
    const invoices = storage.getInvoices();
    if (invoices.length === 0) return 'INV-0001';
    const last = invoices[invoices.length - 1];
    const num = parseInt(last.number.split('-')[1]);
    return `INV-${(num + 1).toString().padStart(4, '0')}`;
  },

  getCompanyProfile: (): CompanyProfile => {
    const data = localStorage.getItem(KEYS.COMPANY);
    return data ? JSON.parse(data) : initialCompany;
  },
  saveCompanyProfile: (profile: CompanyProfile) => localStorage.setItem(KEYS.COMPANY, JSON.stringify(profile)),

  getTaxes: (): TaxSetting[] => {
    const data = localStorage.getItem(KEYS.TAXES);
    return data ? JSON.parse(data) : initialTaxes;
  },
  saveTaxes: (taxes: TaxSetting[]) => localStorage.setItem(KEYS.TAXES, JSON.stringify(taxes)),

  getUsers: (): User[] => {
    const data = localStorage.getItem(KEYS.USERS);
    return data ? JSON.parse(data) : initialUsers;
  },
  saveUsers: (users: User[]) => localStorage.setItem(KEYS.USERS, JSON.stringify(users)),
};