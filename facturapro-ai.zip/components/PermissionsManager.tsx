import React, { useState, useEffect } from 'react';
import { ShieldCheck, UserPlus, Trash2, Mail, MoreVertical, CheckCircle, XCircle } from 'lucide-react';
import { storage } from '../services/storage';
import { User } from '../types';

export const PermissionsManager: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);

  // New User Form State
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<'admin' | 'manager' | 'viewer'>('viewer');

  useEffect(() => {
    setUsers(storage.getUsers());
  }, []);

  const handleAddUser = () => {
    if (!newName || !newEmail) return;

    const newUser: User = {
      id: Date.now().toString(),
      name: newName,
      email: newEmail,
      role: newRole,
      status: 'active',
      lastAccess: new Date().toISOString().split('T')[0]
    };

    const updated = [...users, newUser];
    setUsers(updated);
    storage.saveUsers(updated);

    // Reset Form
    setNewName('');
    setNewEmail('');
    setNewRole('viewer');
    setShowAddForm(false);
  };

  const removeUser = (id: string) => {
    if (confirm('¿Eliminar usuario? Esta acción no se puede deshacer.')) {
      const updated = users.filter(u => u.id !== id);
      setUsers(updated);
      storage.saveUsers(updated);
    }
  };

  const toggleStatus = (id: string) => {
    const updated = users.map(u => 
      u.id === id ? { ...u, status: u.status === 'active' ? 'inactive' as const : 'active' as const } : u
    );
    setUsers(updated);
    storage.saveUsers(updated);
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'admin': return <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs font-bold border border-purple-200">Administrador</span>;
      case 'manager': return <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-bold border border-blue-200">Gestor</span>;
      default: return <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs font-bold border border-gray-200">Visualizador</span>;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 flex items-center">
            <ShieldCheck className="mr-2 text-indigo-600" /> Permisos y Usuarios
          </h2>
          <p className="text-gray-500 text-sm mt-1">Administra el acceso y roles de los miembros del equipo.</p>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center shadow hover:bg-indigo-700 transition w-full sm:w-auto justify-center"
        >
          <UserPlus size={18} className="mr-2" /> Nuevo Usuario
        </button>
      </div>

      {/* Add User Form */}
      {showAddForm && (
        <div className="bg-white p-6 rounded-lg shadow-md border border-indigo-100 animate-slide-down">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Agregar Nuevo Miembro</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Nombre Completo</label>
              <input 
                className="w-full border border-gray-300 p-2 rounded bg-white text-gray-900 focus:ring-2 focus:ring-indigo-500 outline-none" 
                placeholder="Ej. Juan Pérez"
                value={newName}
                onChange={e => setNewName(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Correo Electrónico</label>
              <input 
                type="email"
                className="w-full border border-gray-300 p-2 rounded bg-white text-gray-900 focus:ring-2 focus:ring-indigo-500 outline-none" 
                placeholder="usuario@empresa.com"
                value={newEmail}
                onChange={e => setNewEmail(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Rol de Acceso</label>
              <select 
                className="w-full border border-gray-300 p-2 rounded bg-white text-gray-900 focus:ring-2 focus:ring-indigo-500 outline-none"
                value={newRole}
                onChange={(e) => setNewRole(e.target.value as any)}
              >
                <option value="admin">Administrador (Control Total)</option>
                <option value="manager">Gestor (Facturación y Clientes)</option>
                <option value="viewer">Visualizador (Solo Lectura)</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button onClick={() => setShowAddForm(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded">Cancelar</button>
            <button onClick={handleAddUser} className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Guardar Usuario</button>
          </div>
        </div>
      )}

      {/* Users List */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 text-gray-500 font-semibold text-xs uppercase tracking-wider">
              <tr>
                <th className="p-4 whitespace-nowrap">Usuario</th>
                <th className="p-4 whitespace-nowrap">Rol</th>
                <th className="p-4 whitespace-nowrap">Estado</th>
                <th className="p-4 text-right whitespace-nowrap">Último Acceso</th>
                <th className="p-4 text-center whitespace-nowrap">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50 transition group">
                  <td className="p-4">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 text-white flex items-center justify-center font-bold mr-3 shadow-sm flex-shrink-0">
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 whitespace-nowrap">{user.name}</p>
                        <div className="flex items-center text-xs text-gray-500">
                          <Mail size={12} className="mr-1" /> {user.email}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 whitespace-nowrap">
                    {getRoleBadge(user.role)}
                  </td>
                  <td className="p-4 whitespace-nowrap">
                    <button 
                      onClick={() => toggleStatus(user.id)}
                      className={`flex items-center text-xs font-medium px-2 py-1 rounded-full border transition ${
                        user.status === 'active' 
                          ? 'bg-green-50 text-green-700 border-green-200 hover:bg-green-100' 
                          : 'bg-gray-100 text-gray-500 border-gray-200 hover:bg-gray-200'
                      }`}
                    >
                      {user.status === 'active' ? <CheckCircle size={12} className="mr-1"/> : <XCircle size={12} className="mr-1"/>}
                      {user.status === 'active' ? 'Activo' : 'Inactivo'}
                    </button>
                  </td>
                  <td className="p-4 text-right text-sm text-gray-500 font-mono whitespace-nowrap">
                    {user.lastAccess || 'Nunca'}
                  </td>
                  <td className="p-4 text-center">
                    <button onClick={() => removeUser(user.id)} className="text-gray-300 hover:text-red-500 p-2 rounded-full hover:bg-red-50 transition">
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Role Descriptions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
        <div className="p-4 bg-purple-50 rounded-lg border border-purple-100">
          <h4 className="font-bold text-purple-800 text-sm mb-2">Administrador</h4>
          <p className="text-xs text-purple-600">Acceso total a configuración, impuestos, usuarios y facturación. Puede eliminar registros.</p>
        </div>
        <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
          <h4 className="font-bold text-blue-800 text-sm mb-2">Gestor</h4>
          <p className="text-xs text-blue-600">Puede crear y editar facturas, clientes y productos. No puede modificar configuraciones globales.</p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
          <h4 className="font-bold text-gray-700 text-sm mb-2">Visualizador</h4>
          <p className="text-xs text-gray-500">Solo puede ver facturas y reportes. No puede realizar cambios ni emitir nuevos documentos.</p>
        </div>
      </div>
    </div>
  );
};