import React, { useState, useEffect } from 'react';
import { Plus, Printer, Trash2, CheckCircle } from 'lucide-react';
import { storage } from '../services/storage';
import { Client, Product, Invoice, InvoiceItem, TaxSetting } from '../types';

interface InvoiceManagerProps {
  onPrint: (invoice: Invoice) => void;
}

// Helper for currency formatting (duplicated since we can't easily share utility files without build system changes in this context)
const formatCurrency = (amount: number, currencyCode: string) => {
  try {
    return new Intl.NumberFormat('es-MX', {
      style: 'currency',
      currency: currencyCode,
      minimumFractionDigits: 2
    }).format(amount);
  } catch (e) {
    return `$${amount.toFixed(2)} ${currencyCode}`;
  }
};

export const InvoiceManager: React.FC<InvoiceManagerProps> = ({ onPrint }) => {
  const [view, setView] = useState<'list' | 'create'>('list');
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [availableTaxes, setAvailableTaxes] = useState<TaxSetting[]>([]);
  const [currency, setCurrency] = useState('MXN');

  // Form State
  const [selectedClientId, setSelectedClientId] = useState('');
  const [items, setItems] = useState<InvoiceItem[]>([]);
  
  // Tax Selection State (storing the ID of the selected tax setting)
  const [selectedTaxId, setSelectedTaxId] = useState('');
  const [selectedRetentionId, setSelectedRetentionId] = useState('');

  useEffect(() => {
    setInvoices(storage.getInvoices());
    setClients(storage.getClients());
    setProducts(storage.getProducts());
    setCurrency(storage.getCompanyProfile().currency || 'MXN');
    
    const taxes = storage.getTaxes();
    setAvailableTaxes(taxes);
    
    // Set defaults if available
    const defaultTax = taxes.find(t => t.type === 'tax');
    const defaultRet = taxes.find(t => t.type === 'retention' && t.rate === 0) || taxes.find(t => t.type === 'retention');
    
    if (defaultTax) setSelectedTaxId(defaultTax.id);
    if (defaultRet) setSelectedRetentionId(defaultRet.id);
  }, []);

  const addItem = () => {
    const newItem: InvoiceItem = {
      id: Date.now().toString(),
      productId: '',
      productName: '',
      quantity: 1,
      unitPrice: 0,
      total: 0
    };
    setItems([...items, newItem]);
  };

  const updateItem = (id: string, field: keyof InvoiceItem, value: any) => {
    setItems(items.map(item => {
      if (item.id !== id) return item;
      
      const updated = { ...item, [field]: value };
      
      // Auto-fill product details if product changes
      if (field === 'productId') {
        const prod = products.find(p => p.id === value);
        if (prod) {
          updated.productName = prod.name;
          updated.unitPrice = prod.price;
        }
      }

      updated.total = updated.quantity * updated.unitPrice;
      return updated;
    }));
  };

  const removeItem = (id: string) => {
    setItems(items.filter(i => i.id !== id));
  };

  const getSelectedTaxDetails = () => {
    const tax = availableTaxes.find(t => t.id === selectedTaxId);
    const ret = availableTaxes.find(t => t.id === selectedRetentionId);
    return {
      taxRate: tax ? tax.rate : 0,
      taxName: tax ? tax.name : 'Impuesto',
      retentionRate: ret ? ret.rate : 0,
      retentionName: ret ? ret.name : 'Retención'
    };
  };

  const calculateTotals = () => {
    const { taxRate, retentionRate } = getSelectedTaxDetails();
    const subtotal = items.reduce((acc, item) => acc + item.total, 0);
    const taxAmount = subtotal * taxRate;
    const retentionAmount = subtotal * retentionRate;
    const total = subtotal + taxAmount - retentionAmount;
    return { subtotal, taxAmount, retentionAmount, total };
  };

  const saveInvoice = () => {
    if (!selectedClientId || items.length === 0) {
      alert("Seleccione un cliente y agregue al menos un producto.");
      return;
    }

    const client = clients.find(c => c.id === selectedClientId);
    if (!client) return;

    const totals = calculateTotals();
    const { taxRate, taxName, retentionRate, retentionName } = getSelectedTaxDetails();
    
    const newInvoice: Invoice = {
      id: Date.now().toString(),
      number: storage.getNextInvoiceNumber(),
      clientId: client.id,
      clientName: client.name,
      clientAddress: client.address,
      clientTaxId: client.taxId,
      date: new Date().toISOString().split('T')[0],
      items,
      ...totals,
      taxRate,
      taxName,
      retentionRate,
      retentionName,
      status: 'pending'
    };

    const updatedInvoices = [...invoices, newInvoice];
    setInvoices(updatedInvoices);
    storage.saveInvoices(updatedInvoices);
    setView('list');
    
    // Reset form
    setSelectedClientId('');
    setItems([]);
  };

  const totals = calculateTotals();

  if (view === 'create') {
    return (
      <div className="bg-white rounded-lg shadow-lg p-4 sm:p-6 max-w-4xl mx-auto animate-fade-in">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 border-b pb-4 gap-4">
          <h2 className="text-2xl font-bold text-gray-800">Nueva Factura</h2>
          <button onClick={() => setView('list')} className="text-gray-500 hover:text-gray-700 text-sm bg-gray-100 px-3 py-1 rounded">Cancelar</button>
        </div>

        {/* Client Selector */}
        <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Cliente</label>
            <select 
              className="w-full border border-gray-300 rounded-md p-2 bg-white text-gray-900"
              value={selectedClientId}
              onChange={(e) => setSelectedClientId(e.target.value)}
            >
              <option value="">Seleccione un cliente...</option>
              {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Fecha</label>
            <input type="date" className="w-full border border-gray-300 rounded-md p-2 bg-gray-50 text-gray-700" defaultValue={new Date().toISOString().split('T')[0]} disabled />
          </div>
        </div>

        {/* Items */}
        <div className="mb-6 overflow-x-auto">
          <div className="min-w-[600px]">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-100 text-left text-sm text-gray-600">
                  <th className="p-2 rounded-l w-[35%]">Producto</th>
                  <th className="p-2 w-20">Cant.</th>
                  <th className="p-2 w-24">Precio</th>
                  <th className="p-2 w-24 text-right">Total</th>
                  <th className="p-2 w-10 rounded-r"></th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id} className="border-b">
                    <td className="p-2">
                      <select 
                        className="w-full p-1 border border-gray-300 rounded bg-white text-gray-900 text-sm"
                        value={item.productId}
                        onChange={(e) => updateItem(item.id, 'productId', e.target.value)}
                      >
                        <option value="">Seleccione...</option>
                        {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </td>
                    <td className="p-2">
                      <input type="number" min="1" className="w-full p-1 border border-gray-300 rounded bg-white text-gray-900 text-right text-sm" 
                        value={item.quantity} onChange={(e) => updateItem(item.id, 'quantity', parseFloat(e.target.value))} />
                    </td>
                    <td className="p-2">
                      <input type="number" className="w-full p-1 border border-gray-300 rounded bg-white text-gray-900 text-right text-sm" 
                        value={item.unitPrice} onChange={(e) => updateItem(item.id, 'unitPrice', parseFloat(e.target.value))} />
                    </td>
                    <td className="p-2 text-right font-medium text-sm">{formatCurrency(item.total, currency)}</td>
                    <td className="p-2 text-center">
                      <button onClick={() => removeItem(item.id)} className="text-red-500 hover:text-red-700">
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <button onClick={addItem} className="mt-4 flex items-center text-blue-600 hover:text-blue-800 text-sm font-semibold">
            <Plus size={16} className="mr-1" /> Agregar Fila
          </button>
        </div>

        {/* Footer / Calculations */}
        <div className="flex flex-col md:flex-row justify-between items-start border-t pt-6 gap-6">
          <div className="w-full md:w-1/3 space-y-3">
             <div className="flex flex-col gap-1">
                <label className="text-sm text-gray-600">Tipo de Impuesto (Suma):</label>
                <select 
                  className="border border-gray-300 rounded p-2 text-sm bg-white text-gray-900 w-full"
                  value={selectedTaxId}
                  onChange={(e) => setSelectedTaxId(e.target.value)}
                >
                  <option value="">Seleccionar...</option>
                  {availableTaxes.filter(t => t.type === 'tax').map(t => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
             </div>
             <div className="flex flex-col gap-1">
                <label className="text-sm text-gray-600">Tipo de Retención (Resta):</label>
                <select 
                  className="border border-gray-300 rounded p-2 text-sm bg-white text-gray-900 w-full"
                  value={selectedRetentionId}
                  onChange={(e) => setSelectedRetentionId(e.target.value)}
                >
                  <option value="">Ninguna</option>
                  {availableTaxes.filter(t => t.type === 'retention').map(t => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
             </div>
          </div>
          
          <div className="w-full md:w-1/3 bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-between mb-2">
              <span className="text-gray-600 text-sm">Subtotal</span>
              <span className="font-medium">{formatCurrency(totals.subtotal, currency)}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-gray-600 text-sm">Impuestos (+)</span>
              <span className="font-medium">{formatCurrency(totals.taxAmount, currency)}</span>
            </div>
            {totals.retentionAmount > 0 && (
              <div className="flex justify-between mb-2 text-red-600">
                <span className="text-sm">Retenciones (-)</span>
                <span>-{formatCurrency(totals.retentionAmount, currency)}</span>
              </div>
            )}
            <div className="flex justify-between pt-2 border-t border-gray-300">
              <span className="text-lg font-bold text-gray-900">Total</span>
              <span className="text-lg font-bold text-blue-600">{formatCurrency(totals.total, currency)}</span>
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-end gap-3 flex-wrap">
           <button onClick={() => setView('list')} className="w-full sm:w-auto px-4 py-2 text-gray-700 bg-gray-100 rounded hover:bg-gray-200">
             Cancelar
           </button>
           <button onClick={saveInvoice} className="w-full sm:w-auto px-6 py-2 bg-blue-600 text-white rounded shadow hover:bg-blue-700 flex items-center justify-center">
             <CheckCircle size={18} className="mr-2" /> Guardar Factura
           </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-800">Facturas</h2>
        <button onClick={() => setView('create')} className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center shadow hover:bg-blue-700 transition w-full sm:w-auto justify-center">
          <Plus size={18} className="mr-2" /> Nueva Factura
        </button>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 text-gray-500 font-semibold text-sm">
              <tr>
                <th className="p-4 whitespace-nowrap">Número</th>
                <th className="p-4 whitespace-nowrap">Cliente</th>
                <th className="p-4 whitespace-nowrap">Fecha</th>
                <th className="p-4 text-right whitespace-nowrap">Total</th>
                <th className="p-4 text-center whitespace-nowrap">Estado</th>
                <th className="p-4 text-center whitespace-nowrap">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {invoices.length === 0 ? (
                <tr><td colSpan={6} className="p-8 text-center text-gray-500">No hay facturas registradas.</td></tr>
              ) : invoices.map(inv => (
                <tr key={inv.id} className="hover:bg-gray-50 transition">
                  <td className="p-4 font-medium text-gray-900 whitespace-nowrap">{inv.number}</td>
                  <td className="p-4 whitespace-nowrap">{inv.clientName}</td>
                  <td className="p-4 text-gray-600 whitespace-nowrap">{inv.date}</td>
                  <td className="p-4 text-right font-semibold whitespace-nowrap">{formatCurrency(inv.total, currency)}</td>
                  <td className="p-4 text-center whitespace-nowrap">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${inv.status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                      {inv.status === 'paid' ? 'Pagada' : 'Pendiente'}
                    </span>
                  </td>
                  <td className="p-4 flex justify-center gap-2">
                    <button onClick={() => onPrint(inv)} className="text-gray-500 hover:text-blue-600 p-1" title="Imprimir/PDF">
                      <Printer size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};