import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Percent } from 'lucide-react';
import { storage } from '../services/storage';
import { TaxSetting } from '../types';

export const TaxManager: React.FC = () => {
  const [taxes, setTaxes] = useState<TaxSetting[]>([]);
  
  // Form State
  const [newName, setNewName] = useState('');
  const [newRate, setNewRate] = useState('');
  const [newType, setNewType] = useState<'tax' | 'retention'>('tax');

  useEffect(() => {
    setTaxes(storage.getTaxes());
  }, []);

  const addTax = () => {
    if (!newName || newRate === '') return;
    
    const rateValue = parseFloat(newRate) / 100; // Convert 16 to 0.16
    
    const newTax: TaxSetting = {
      id: Date.now().toString(),
      name: newName,
      rate: rateValue,
      type: newType
    };

    const updated = [...taxes, newTax];
    setTaxes(updated);
    storage.saveTaxes(updated);
    
    // Reset
    setNewName('');
    setNewRate('');
  };

  const removeTax = (id: string) => {
    if (confirm('¿Estás seguro de eliminar este impuesto?')) {
      const updated = taxes.filter(t => t.id !== id);
      setTaxes(updated);
      storage.saveTaxes(updated);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6 animate-fade-in">
      <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
        <Percent className="mr-2" size={20} /> Configuración de Impuestos
      </h2>
      
      <p className="text-sm text-gray-600 mb-6">
        Define los impuestos y retenciones aplicables en tu región. Estos estarán disponibles al momento de crear facturas.
      </p>

      {/* Form */}
      <div className="bg-gray-50 p-4 rounded-lg mb-8 border border-gray-200">
        <h3 className="text-xs font-bold text-gray-500 mb-3 uppercase tracking-wider">Agregar Nuevo</h3>
        <div className="flex flex-col lg:flex-row gap-4 items-end">
          <div className="flex-1 w-full">
            <label className="block text-xs font-medium text-gray-500 mb-1">Nombre (ej. IVA General)</label>
            <input 
              className="w-full border border-gray-300 p-2 rounded bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 outline-none text-sm" 
              placeholder="Nombre del impuesto" 
              value={newName} 
              onChange={e => setNewName(e.target.value)} 
            />
          </div>
          <div className="w-full lg:w-32">
            <label className="block text-xs font-medium text-gray-500 mb-1">Porcentaje %</label>
            <input 
              type="number" 
              className="w-full border border-gray-300 p-2 rounded bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 outline-none text-sm" 
              placeholder="16" 
              value={newRate} 
              onChange={e => setNewRate(e.target.value)} 
            />
          </div>
          <div className="w-full lg:w-48">
            <label className="block text-xs font-medium text-gray-500 mb-1">Tipo</label>
            <select 
              className="w-full border border-gray-300 p-2 rounded bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 outline-none text-sm"
              value={newType}
              onChange={(e) => setNewType(e.target.value as 'tax' | 'retention')}
            >
              <option value="tax">Impuesto (Suma)</option>
              <option value="retention">Retención (Resta)</option>
            </select>
          </div>
          <button 
            onClick={addTax} 
            className="w-full lg:w-auto bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 flex items-center justify-center font-medium text-sm"
          >
            <Plus size={16} className="mr-1" /> Agregar
          </button>
        </div>
      </div>

      {/* List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Taxes */}
        <div>
          <h3 className="text-sm font-bold text-gray-700 mb-3 border-b pb-2">Impuestos (Suman)</h3>
          <ul className="space-y-2">
            {taxes.filter(t => t.type === 'tax').map(tax => (
              <li key={tax.id} className="flex justify-between items-center p-3 bg-white border rounded hover:border-blue-300 transition group">
                <div>
                  <span className="font-medium text-gray-800 text-sm">{tax.name}</span>
                  <span className="ml-2 text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-bold">{(tax.rate * 100).toFixed(2)}%</span>
                </div>
                <button onClick={() => removeTax(tax.id)} className="text-gray-300 hover:text-red-500 transition">
                  <Trash2 size={14} />
                </button>
              </li>
            ))}
            {taxes.filter(t => t.type === 'tax').length === 0 && (
              <li className="text-sm text-gray-400 italic p-2">No hay impuestos configurados.</li>
            )}
          </ul>
        </div>

        {/* Retentions */}
        <div>
          <h3 className="text-sm font-bold text-gray-700 mb-3 border-b pb-2">Retenciones (Restan)</h3>
          <ul className="space-y-2">
            {taxes.filter(t => t.type === 'retention').map(tax => (
              <li key={tax.id} className="flex justify-between items-center p-3 bg-white border rounded hover:border-red-300 transition group">
                <div>
                  <span className="font-medium text-gray-800 text-sm">{tax.name}</span>
                  <span className="ml-2 text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-bold">-{(tax.rate * 100).toFixed(2)}%</span>
                </div>
                <button onClick={() => removeTax(tax.id)} className="text-gray-300 hover:text-red-500 transition">
                  <Trash2 size={14} />
                </button>
              </li>
            ))}
            {taxes.filter(t => t.type === 'retention').length === 0 && (
               <li className="text-sm text-gray-400 italic p-2">No hay retenciones configuradas.</li>
            )}
          </ul>
        </div>

      </div>
    </div>
  );
};