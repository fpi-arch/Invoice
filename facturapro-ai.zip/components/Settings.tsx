import React, { useState, useEffect } from 'react';
import { Save, Wand2, Loader2, Image as ImageIcon, Building2, Percent, Coins, Server, Key, Globe, Lock, ShieldCheck } from 'lucide-react';
import { storage } from '../services/storage';
import { CompanyProfile, ApiConfig } from '../types';
import { generateLogo } from '../services/geminiService';
import { TaxManager } from './TaxManager';

export const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'general' | 'taxes' | 'apis'>('general');
  const [profile, setProfile] = useState<CompanyProfile>(storage.getCompanyProfile());
  const [logoPrompt, setLogoPrompt] = useState('Finanzas, tecnología, crecimiento, azul y blanco');
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');

  // Local state for API form to handle nested objects easily before saving
  const [apiConfig, setApiConfig] = useState<ApiConfig>(
    profile.apiConfig || { provider: 'GENERIC', environment: 'sandbox', apiKey: '', apiSecret: '' }
  );

  const handleChange = (field: keyof CompanyProfile, value: string) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  const handleApiChange = (field: keyof ApiConfig, value: string) => {
    setApiConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    const updatedProfile = { ...profile, apiConfig };
    setProfile(updatedProfile);
    storage.saveCompanyProfile(updatedProfile);
    alert('Configuración guardada exitosamente.');
    window.dispatchEvent(new Event('storage'));
  };

  const handleGenerateLogo = async () => {
    setGenerating(true);
    setError('');
    try {
      const base64Image = await generateLogo(profile.name, logoPrompt);
      if (base64Image) {
        setProfile(prev => ({ ...prev, logoUrl: base64Image }));
      } else {
        setError('No se pudo generar la imagen. Intente nuevamente.');
      }
    } catch (e) {
      setError('Error al conectar con el servicio de IA.');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Tab Navigation */}
      <div className="flex overflow-x-auto space-x-1 bg-gray-200 p-1 rounded-lg w-full sm:w-fit mb-6">
        <button
          onClick={() => setActiveTab('general')}
          className={`flex items-center justify-center px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
            activeTab === 'general' 
              ? 'bg-white text-blue-600 shadow-sm' 
              : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
          }`}
        >
          <Building2 size={16} className="mr-2" /> Datos Empresa
        </button>
        <button
          onClick={() => setActiveTab('taxes')}
          className={`flex items-center justify-center px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
            activeTab === 'taxes' 
              ? 'bg-white text-blue-600 shadow-sm' 
              : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
          }`}
        >
          <Percent size={16} className="mr-2" /> Impuestos
        </button>
        <button
          onClick={() => setActiveTab('apis')}
          className={`flex items-center justify-center px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
            activeTab === 'apis' 
              ? 'bg-white text-blue-600 shadow-sm' 
              : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
          }`}
        >
          <Server size={16} className="mr-2" /> Integraciones API
        </button>
      </div>

      {activeTab === 'taxes' && <TaxManager />}

      {activeTab === 'apis' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in">
          {/* Main Configuration */}
          <div className="col-span-2 bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-bold mb-6 flex items-center text-gray-800">
              <Globe className="mr-2 text-indigo-600" size={20} /> Conexión Facturación Electrónica
            </h2>
            
            <div className="space-y-5">
              <div className="bg-blue-50 border border-blue-200 p-4 rounded-md text-sm text-blue-800 mb-4 flex items-start">
                <ShieldCheck size={18} className="mr-2 mt-0.5 flex-shrink-0"/>
                <p>Las credenciales se guardan localmente en este dispositivo. Para un entorno de producción real, asegúrese de implementar estas claves en un servidor seguro.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Proveedor / Certificador (PAC)</label>
                  <select 
                    className="w-full border border-gray-300 rounded p-2 bg-white text-gray-900 focus:ring-2 focus:ring-indigo-500"
                    value={apiConfig.provider}
                    onChange={(e) => handleApiChange('provider', e.target.value)}
                  >
                    <option value="SAT_GT_FEL">SAT Guatemala (FEL - Infile/Guatefacturas)</option>
                    <option value="SAT_MX">SAT México (Timbrado Genérico)</option>
                    <option value="DIAN_CO">DIAN Colombia</option>
                    <option value="GENERIC">API Genérica / Otro</option>
                  </select>
                </div>

                <div>
                   <label className="block text-sm font-medium text-gray-700 mb-1">Entorno</label>
                   <div className="flex bg-gray-100 p-1 rounded-md">
                      <button 
                        onClick={() => handleApiChange('environment', 'sandbox')}
                        className={`flex-1 py-1.5 px-3 rounded text-sm font-medium transition ${apiConfig.environment === 'sandbox' ? 'bg-white shadow text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                      >
                        Pruebas / Sandbox
                      </button>
                      <button 
                         onClick={() => handleApiChange('environment', 'production')}
                         className={`flex-1 py-1.5 px-3 rounded text-sm font-medium transition ${apiConfig.environment === 'production' ? 'bg-red-50 shadow text-red-600 border border-red-100' : 'text-gray-500 hover:text-gray-700'}`}
                      >
                        Producción
                      </button>
                   </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Endpoint URL (Opcional)</label>
                  <input 
                    type="text" 
                    className="w-full border border-gray-300 rounded p-2 bg-white text-gray-900 focus:ring-2 focus:ring-indigo-500 text-sm"
                    placeholder="https://api.certificador.com/v1"
                    value={apiConfig.endpointUrl || ''}
                    onChange={(e) => handleApiChange('endpointUrl', e.target.value)}
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                    <Key size={14} className="mr-1 text-gray-500"/> Usuario / API Key
                  </label>
                  <input 
                    type="text" 
                    className="w-full border border-gray-300 rounded p-2 bg-white text-gray-900 focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
                    placeholder="Ej. Usuario_SAT_12345"
                    value={apiConfig.apiKey}
                    onChange={(e) => handleApiChange('apiKey', e.target.value)}
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                    <Lock size={14} className="mr-1 text-gray-500"/> Contraseña / Token Secreto
                  </label>
                  <input 
                    type="password" 
                    className="w-full border border-gray-300 rounded p-2 bg-white text-gray-900 focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
                    placeholder="••••••••••••••••"
                    value={apiConfig.apiSecret}
                    onChange={(e) => handleApiChange('apiSecret', e.target.value)}
                  />
                </div>

                {(apiConfig.provider === 'SAT_GT_FEL' || apiConfig.provider === 'SAT_MX') && (
                  <div className="col-span-2 border-t pt-4 mt-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Contraseña de Certificado (.p12 / .key)</label>
                    <input 
                      type="password" 
                      className="w-full border border-gray-300 rounded p-2 bg-white text-gray-900 focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
                      placeholder="Pass frase del certificado"
                      value={apiConfig.certPassword || ''}
                      onChange={(e) => handleApiChange('certPassword', e.target.value)}
                    />
                    <p className="text-xs text-gray-500 mt-1">Requerido para firmar digitalmente el XML antes de enviar.</p>
                  </div>
                )}
              </div>

              <div className="pt-4 flex justify-end">
                <button 
                  onClick={handleSave}
                  className="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700 transition font-medium flex items-center shadow-sm"
                >
                  <Save size={18} className="mr-2" /> Guardar Credenciales
                </button>
              </div>
            </div>
          </div>

          {/* Status / Info Panel */}
          <div className="col-span-1 space-y-6">
            <div className="bg-white rounded-lg shadow p-6 border-t-4 border-gray-300">
               <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">Estado de Conexión</h3>
               <div className="flex items-center space-x-3 mb-4">
                  <div className={`w-3 h-3 rounded-full ${apiConfig.apiKey ? 'bg-green-500 animate-pulse' : 'bg-red-400'}`}></div>
                  <span className="font-medium text-gray-700">{apiConfig.apiKey ? 'Configurado (Listo)' : 'Sin Configurar'}</span>
               </div>
               <p className="text-xs text-gray-500">
                 {apiConfig.environment === 'production' 
                   ? '⚠️ Modo Producción: Las facturas generadas tendrán validez fiscal real.' 
                   : '✅ Modo Sandbox: Las facturas son solo pruebas y no tienen valor fiscal.'}
               </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
              <h3 className="text-sm font-bold text-gray-700 mb-2">Ayuda {apiConfig.provider.replace(/_/g, ' ')}</h3>
              <p className="text-xs text-gray-600 mb-2">
                Para obtener tus credenciales API:
              </p>
              <ul className="text-xs text-gray-600 list-disc pl-4 space-y-1">
                <li>Ingresa al portal de tu certificador (Ej. Infile, Guatefacturas, SAT).</li>
                <li>Navega a la sección de "Desarrolladores" o "Integraciones".</li>
                <li>Genera un nuevo par de llaves (API Key y Secret).</li>
                <li>Asegúrate de habilitar los permisos de emisión.</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'general' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fade-in">
          {/* Company Details */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-bold mb-6 flex items-center text-gray-800">
              <Save className="mr-2" size={20} /> Datos de la Empresa
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nombre / Razón Social</label>
                <input 
                  type="text" 
                  className="w-full border border-gray-300 rounded p-2 bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  value={profile.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">RFC / Identificación Fiscal</label>
                <input 
                  type="text" 
                  className="w-full border border-gray-300 rounded p-2 bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  value={profile.taxId}
                  onChange={(e) => handleChange('taxId', e.target.value)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Dirección Fiscal</label>
                <textarea 
                  className="w-full border border-gray-300 rounded p-2 h-24 bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  value={profile.address}
                  onChange={(e) => handleChange('address', e.target.value)}
                />
              </div>

              <div>
                 <label className="block text-sm font-medium text-gray-700 mb-1">Moneda del Sistema</label>
                 <div className="relative">
                   <Coins size={16} className="absolute left-3 top-3 text-gray-400" />
                   <select 
                     className="w-full border border-gray-300 rounded p-2 pl-9 bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                     value={profile.currency || 'MXN'}
                     onChange={(e) => handleChange('currency', e.target.value)}
                   >
                     <option value="MXN">Peso Mexicano (MXN)</option>
                     <option value="USD">Dólar Americano (USD)</option>
                     <option value="EUR">Euro (EUR)</option>
                     <option value="GTQ">Quetzal Guatemalteco (GTQ)</option>
                     <option value="COP">Peso Colombiano (COP)</option>
                     <option value="ARS">Peso Argentino (ARS)</option>
                     <option value="PEN">Sol Peruano (PEN)</option>
                     <option value="CLP">Peso Chileno (CLP)</option>
                     <option value="CRC">Colón Costarricense (CRC)</option>
                   </select>
                 </div>
                 <p className="text-xs text-gray-500 mt-1">Esta moneda se mostrará en productos, facturas y reportes.</p>
              </div>

              <button 
                onClick={handleSave}
                className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition font-medium"
              >
                Guardar Cambios
              </button>
            </div>
          </div>

          {/* Logo Generator */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-bold mb-6 flex items-center text-gray-800">
              <ImageIcon className="mr-2" size={20} /> Logotipo
            </h2>

            <div className="mb-6 flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-6 bg-gray-50">
              {profile.logoUrl ? (
                <div className="text-center">
                   <img src={profile.logoUrl} alt="Logo Empresa" className="h-32 object-contain mx-auto mb-2" />
                   <button onClick={() => handleChange('logoUrl', '')} className="text-xs text-red-500 hover:underline">Eliminar Logo</button>
                </div>
              ) : (
                <div className="text-center text-gray-400">
                  <ImageIcon size={48} className="mx-auto mb-2 opacity-50" />
                  <p>Sin logotipo asignado</p>
                </div>
              )}
            </div>

            <div className="border-t pt-6">
              <h3 className="text-md font-semibold mb-3 flex items-center text-indigo-900">
                <Wand2 className="mr-2 text-indigo-600" size={18} /> Generador con IA
              </h3>
              <p className="text-xs text-gray-500 mb-3">
                Describe el estilo de tu empresa y Gemini creará un logotipo único para tus facturas.
              </p>
              
              <div className="space-y-3">
                <textarea 
                  className="w-full border border-indigo-200 rounded p-2 text-sm bg-indigo-50 text-gray-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Ej: Minimalista, geométrico, colores azules, símbolo de crecimiento..."
                  value={logoPrompt}
                  onChange={(e) => setLogoPrompt(e.target.value)}
                />
                
                {error && <p className="text-xs text-red-500">{error}</p>}

                <button 
                  onClick={handleGenerateLogo}
                  disabled={generating}
                  className="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700 transition flex items-center justify-center disabled:opacity-70"
                >
                  {generating ? (
                    <><Loader2 className="animate-spin mr-2" size={18} /> Generando...</>
                  ) : (
                    <><Wand2 className="mr-2" size={18} /> Generar Logo</>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};