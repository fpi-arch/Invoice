import React, { useEffect, useState } from 'react';
import { Invoice, CompanyProfile } from '../types';
import { storage } from '../services/storage';

interface InvoicePDFProps {
  invoice: Invoice | null;
}

// Helper for currency formatting (duplicated to avoid build complexity)
const formatCurrency = (amount: number, currencyCode: string) => {
  try {
    return new Intl.NumberFormat('es-MX', {
      style: 'currency',
      currency: currencyCode,
      minimumFractionDigits: 2
    }).format(amount);
  } catch (e) {
    return `$${amount.toFixed(2)} ${currencyCode}`;
  }
};

export const InvoicePDF: React.FC<InvoicePDFProps> = ({ invoice }) => {
  const [company, setCompany] = useState<CompanyProfile>(storage.getCompanyProfile());

  // Listen for storage changes in case settings updated
  useEffect(() => {
    const handleStorageChange = () => setCompany(storage.getCompanyProfile());
    window.addEventListener('storage', handleStorageChange);
    // Also update on mount
    setCompany(storage.getCompanyProfile());
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [invoice]); // Re-check when invoice changes just in case

  if (!invoice) return null;
  const currency = company.currency || 'MXN';

  return (
    <div className="w-full overflow-x-auto">
      <div className="p-10 min-w-[800px] max-w-4xl mx-auto bg-white text-black shadow-2xl my-8 border border-gray-200" id="printable-invoice">
        {/* Header */}
        <div className="flex justify-between items-start mb-8 border-b pb-4">
          <div className="flex items-start">
            {company.logoUrl && (
               <img src={company.logoUrl} alt="Logo" className="w-24 h-24 object-contain mr-6 rounded" />
            )}
            <div>
              <h1 className="text-3xl font-bold text-gray-800">FACTURA</h1>
              <p className="text-sm font-bold text-gray-700 mt-2">{company.name}</p>
              <p className="text-sm text-gray-500">RFC: {company.taxId}</p>
              <p className="text-sm text-gray-500 max-w-xs">{company.address}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500 uppercase tracking-wider mb-1 font-semibold">Folio</p>
            <h2 className="text-2xl font-bold text-red-600">{invoice.number}</h2>
            <p className="text-sm text-gray-500 mt-2">Fecha de Emisión</p>
            <p className="text-gray-800 font-medium">{invoice.date}</p>
          </div>
        </div>

        {/* Client Info */}
        <div className="mb-8 p-4 bg-gray-50 rounded border border-gray-100">
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Facturar a:</h3>
          <p className="font-bold text-lg text-gray-900">{invoice.clientName}</p>
          <div className="text-sm text-gray-600 mt-1">
            <p>RFC/ID: {invoice.clientTaxId}</p>
            <p>{invoice.clientAddress}</p>
            {invoice.clientAddress.includes('México') === false && (
                <span className="text-xs text-gray-400 mt-1 block">Extranjero</span>
            )}
          </div>
        </div>

        {/* Items Table */}
        <table className="w-full mb-8">
          <thead>
            <tr className="border-b-2 border-gray-200">
              <th className="text-left py-2 font-bold text-gray-700 uppercase text-xs tracking-wider">Descripción</th>
              <th className="text-right py-2 font-bold text-gray-700 uppercase text-xs tracking-wider">Cant.</th>
              <th className="text-right py-2 font-bold text-gray-700 uppercase text-xs tracking-wider">Precio Unit.</th>
              <th className="text-right py-2 font-bold text-gray-700 uppercase text-xs tracking-wider">Total</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items.map((item) => (
              <tr key={item.id} className="border-b border-gray-100">
                <td className="py-3 text-gray-800">
                    <p className="font-medium">{item.productName}</p>
                    <p className="text-xs text-gray-500">ID: {item.productId}</p>
                </td>
                <td className="py-3 text-right text-gray-600">{item.quantity}</td>
                <td className="py-3 text-right text-gray-600">${item.unitPrice.toFixed(2)}</td>
                <td className="py-3 text-right font-medium text-gray-900">{formatCurrency(item.total, currency)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Totals */}
        <div className="flex justify-end">
          <div className="w-64 space-y-2">
            <div className="flex justify-between text-gray-600">
              <span>Subtotal:</span>
              <span>{formatCurrency(invoice.subtotal, currency)}</span>
            </div>
            <div className="flex justify-between text-gray-600">
              {/* Fallback to generic name if taxName isn't saved (backward compatibility) */}
              <span>{invoice.taxName || `IVA ${(invoice.taxRate * 100).toFixed(0)}%`}:</span>
              <span>{formatCurrency(invoice.taxAmount, currency)}</span>
            </div>
            {invoice.retentionAmount > 0 && (
              <div className="flex justify-between text-red-500">
                <span>{invoice.retentionName || 'Retención'} (-):</span>
                <span>-{formatCurrency(invoice.retentionAmount, currency)}</span>
              </div>
            )}
            <div className="flex justify-between border-t-2 border-gray-800 pt-2 mt-2">
              <span className="font-bold text-xl text-gray-900">Total:</span>
              <span className="font-bold text-xl text-blue-600">{formatCurrency(invoice.total, currency)}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-16 pt-8 border-t border-gray-200 text-center">
          <p className="text-sm font-medium text-gray-600">Gracias por su preferencia.</p>
          <p className="text-xs text-gray-400 mt-2">Este documento es una representación impresa de una factura generada digitalmente.</p>
        </div>
      </div>
    </div>
  );
};